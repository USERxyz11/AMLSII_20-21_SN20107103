import pandas as pd 
from bs4 import BeautifulSoup
import re
from nltk.corpus import stopwords # Import the stop word list
from sklearn.feature_extraction.text import CountVectorizer  
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score, roc_curve
import nltk.data
from gensim.models import word2vec
import numpy as np
from sklearn.preprocessing import LabelEncoder
import string
from sklearn.metrics import accuracy_score, roc_auc_score, roc_curve
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from sklearn.metrics import f1_score
from gensim.models import Word2Vec
from keras.preprocessing.sequence import pad_sequences
from keras.preprocessing.text import Tokenizer
from keras.utils import np_utils
from keras.layers.merge import concatenate
from keras.models import Sequential, Model
from keras.layers import Dense, Embedding, Activation, Input
from keras.layers import Convolution1D, Flatten, Dropout, MaxPool1D
from keras.layers import  BatchNormalization
from keras.layers import Convolution1D, Conv1D,MaxPooling1D
from keras.layers import Dense, Embedding, Input, Lambda, Reshape
from keras.layers import Convolution1D, Flatten, Dropout, MaxPool1D, GlobalAveragePooling1D
from keras.layers import LSTM, GRU, TimeDistributed, Bidirectional
from keras.utils import to_categorical
from keras.utils import to_categorical

#Type of classification.This experiment is divided into three categories.
NUM_CLASS=3
#Maximum length of input text
INPUT_SIZE=160
#The maximum number of words retained by the tokenizer
num_most_freq_words_to_include=5000

#Read the data and change the sentiment label from text to number
def read_data():
    train = pd.read_csv("./Dataset/twitter-2016train-A.txt", names=['id','sentiment','message'],
                    delimiter="\t", quoting=3,index_col=False )

    train.loc[train['sentiment']=='negative','sentiment']=0
    train.loc[train['sentiment']=='neutral','sentiment']=1
    train.loc[train['sentiment']=='positive','sentiment']=2

    train['sentiment']=train['sentiment'].astype(int)
    return train

#Lowercase all text
def text_to_lowercase(text):
    return text.lower()

#Remove punctuation
def text_remove_punctuation(text):
    return text.translate(str.maketrans('', '', string.punctuation))

#Remove url
def text_remove_url(text):
    return re.sub(r"http\S+", "", text)

#Remove the @ symbol
def text_remove_twitter_handle(text):
    return re.sub('@[^\s]+','',text)

#Remove the specified characters at the beginning and end of the string (the default is a space or newline)
def text_remove_leadtrail_spaces(text):
    return text.strip()

#Clean text data
def clean_text(text):
    text1 = text_remove_twitter_handle(text)
    text2 = text_remove_url(text1)
    text3 = text_remove_punctuation(text2)
    text4 = text_to_lowercase(text3)
    text5 = text_remove_leadtrail_spaces(text4)
    return text5

#Clean twitter text data
def clean(train):
    train['message'] =[clean_text(i) for i in train["message"]]
    return train['message']

#Use tokenizer to convert text data into digital data
def text_num(feature):
    #Separate irrelevant characters again
    tokenizer = Tokenizer(filters='!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n',
                          lower=True,split=" ",num_words=num_most_freq_words_to_include)
    tokenizer.fit_on_texts(feature)
    #Keep the tokenizer directory so that Word2Vec can use it to build a matrix
    vocab = tokenizer.word_index
    #Use tokenizer to convert text into numbers
    x_ids=tokenizer.texts_to_sequences(feature)
    #Uniform length of all data
    pad_s=pad_sequences(x_ids, maxlen=INPUT_SIZE)
    return pad_s,vocab

#Use Word2Vec to build word vector matrix
def W2V_model(feature,vocab):
    w2v_model=Word2Vec(feature, size=500, sg=0,hs=0,window=6, iter=8,min_count=7)
    embeding_matrix=np.zeros((len(vocab)+1,500))
    for word,i in vocab.items():
        try:
            embeding_vector=w2v_model[str(word)]
            embeding_matrix[i]=embeding_vector
        except KeyError:
            continue
    return embeding_matrix

#Divide the data set
def divide_data(target,pad_s):
    encoder = LabelEncoder()
    encoded_Y = encoder.fit_transform(target)
    # convert integers to dummy variables (one hot encoding)
    target_u = np_utils.to_categorical(encoded_Y)

    X_train,X_test,y_train,y_test=train_test_split(pad_s,target_u,random_state=22,test_size=0.2)
    X_train,X_val,y_train,y_val=train_test_split(X_train,y_train,random_state=20,test_size=0.2)
    return  X_train,X_test,X_val,y_train,y_test,y_val

#Use LSTM training data and evaluate the results
def built_model(X_train,X_test,X_val,y_train,y_test,y_val,embeding_matrix,vocab):
    model = Sequential()
    model.add(Embedding(len(vocab)+1,500,input_length=INPUT_SIZE,weights=[embeding_matrix],trainable=True))
    #model.add(Embedding(len(vocab)+1,500,input_length=INPUT_SIZE,trainable=True))
    model.add(LSTM(256, dropout=0.5, recurrent_dropout=0.1))
    model.add(Dense(NUM_CLASS, activation='softmax'))
    model.summary()
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    print('Train TaskA...')
    model.fit(X_train, y_train,
              batch_size=32,
              epochs=1,
              validation_data=[X_val,y_val]
              )
    result=model.predict(X_test)
    result=np.argmax(result, axis=-1)
    y_test=np.argmax(y_test, axis=-1)
    print('Result TaskA...')
    print(classification_report(y_test, result))



def taskA():
    train=read_data()
    feature=clean(train)
    target=train['sentiment']
    pad_s,vocab=text_num(feature)
    embeding_matrix=W2V_model(feature,vocab)
    X_train,X_test,X_val,y_train,y_test,y_val=divide_data(target,pad_s)
    built_model(X_train,X_test,X_val,y_train,y_test,y_val,embeding_matrix,vocab)
    
