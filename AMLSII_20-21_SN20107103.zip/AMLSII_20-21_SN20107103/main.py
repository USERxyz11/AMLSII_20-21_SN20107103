
from A import twitterA as taskA
from B import twitterB as taskB

taskA.taskA()

taskB.taskB()